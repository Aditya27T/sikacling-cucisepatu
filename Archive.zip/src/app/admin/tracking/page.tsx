// app/admin/tracking/page.tsx
import AdminTrackingClient from '@/components/admin/AdminTrackingClient';

export default function AdminTrackingPage() {
  return <AdminTrackingClient />;
}