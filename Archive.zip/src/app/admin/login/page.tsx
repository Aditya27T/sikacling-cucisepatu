// app/admin/login/page.tsx
import LoginClient from '@/components/admin/LoginClient';

export default function AdminLoginPage() {
  return <LoginClient />;
}