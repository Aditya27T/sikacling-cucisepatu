// app/admin/page.tsx
import AdminDashboardClient from '@/components/admin/AdminDashboardClient';

export default function AdminDashboardPage() {
  return <AdminDashboardClient />;
}