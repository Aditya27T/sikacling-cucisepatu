// app/admin/bookings/page.tsx
import AdminBookingsClient from '@/components/admin/AdminBookingsClient';

export default function AdminBookingsPage() {
  return <AdminBookingsClient />;
}