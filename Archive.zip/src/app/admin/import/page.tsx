// app/admin/import/page.tsx
import ImportDataClient from '@/components/admin/ImportDataClient';

export default function ImportDataPage() {
  return <ImportDataClient />;
}